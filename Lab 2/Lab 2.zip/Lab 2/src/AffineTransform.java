public class AffineTransform {

    public String getName() {
        return "";
    }
    //these have to be in each of the IFS \/
    public double[][] getAffine() {
        return null;
    }
    public double getScale() {
    return 0.0;
    }
    public int getHeight() {
        return 0;
    }
    public int getWidth() {
        return 0;
    }
    public int getXoffset() {
        return 0;
    }
    public int getYoffset() {
        return 0;
    }
}
